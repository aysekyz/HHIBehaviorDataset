%--------------------------------------------------------------------------
% Software License Agreement (BSD License)
%
%  Copyright (c) 2014, Koc University
%  All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions
%  are met:
%
%   * Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer.
%   * Redistributions in binary form must reproduce the above
%     copyright notice, this list of conditions and the following
%     disclaimer in the documentation and/or other materials provided
%     with the distribution.
%   * Neither the name of Koc University nor the names of its
%     contributors may be used to endorse or promote products derived
%     from this software without specific prior written permission.
%
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
%  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
%  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
%  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
%  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
%  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
%  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
%  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
%  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
%  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
%  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
%  POSSIBILITY OF SUCH DAMAGE.
%
% Author: Ayse Kucukyilmaz
%--------------------------------------------------------------------------

% Given data, create videos that simulate the interaction sequence
% It assumes that the data resides in a folder named matFiles under <PATH> 
% (see below) directory 
%
% The videos are put into a folder named videos under <PATH> 
% (see below) directory 
%--------------------------------------------------------------------------

clc;
clear;
close all;

PATH = '../../..'; % change this 

cd '../analysis-compact';
init;
USERS = [12 16 17];
TRIAL_COUNT = 10;

% return
cd '../simulateTrials';

SCALE_FACTOR = 5; % for scaling the forces in visualization...


MAZE_WIDTH  = 200;
MAZE_HEIGHT = 5;
MAZE_DEPTH_ALL_SC = [30; 0; 83];

%Define obstacles for mixed scenario
obs1 = [  0 15; 100 15; 100 -15; 0 -15; 0 15];
obs2 = [ -100 41; -30 41; -30 15; -100 15; -100 41 ];
obs3 = [ -100 -41; -30 -41; -30 -15; -100 -15; -100 -41];

% Block specification; table and participants
Ly_table = 4;
Lx_table = 8;
Lz_table = 3;

dia = sqrt(((Lx_table/2)^2) + ((Ly_table/2)^2));
dia_angle = atan(Ly_table/Lx_table);

Ly1 = 0.1;
Lx1 = 0.1;
Lz1 = 0.1;
dia1 = sqrt(((Lx1/2)^2) + ((Ly1/2)^2));
dia_angle1 = atan(Ly1/Lx1);


Ly2 = 0.1;
Lx2 = 0.1;
Lz2 = 0.1;
dia2 = sqrt(((Lx2/2)^2) + ((Ly2/2)^2));
dia_angle2 = atan(Ly2/Lx2);

counter = 0;

for sc = 1
    
    MAZE_DEPTH = MAZE_DEPTH_ALL_SC(sc);
    for user = USERS
        user
        
        if user == 1 || user == 2 || user == 3 || user ==16
            perm = 0;
        elseif user == 4 || user==5 || user == 6 || user == 17
            perm = 1;
        elseif user ==7 || user == 8 || user == 9 || user ==18
            perm = 2;
        elseif user == 10 || user == 11 || user == 12 || user ==19 || user == 21
            perm = 3;
        else
            perm =4;
        end
        
        if(user < 10)
            filename = sprintf('../matFiles/expData_u0%d_perm0%d_sc%0d.mat',user,perm,sc);
        else
            filename = sprintf('../matFiles/expData_u%d_perm0%d_sc%0d.mat',user,perm,sc);
        end
        
        load (filename);
        
        if user == 12
            start = 6;      
        else
            start = 1;
        end
        
        for trial = start:TRIAL_COUNT
            trial
            if user < 10
                savePath = sprintf('%s/videos/s0%d_u0%d_t%d.avi', PATH, sc, user,trial);
            else
                savePath = sprintf('%s/videos/s0%d_u%d_t%d.avi', PATH, sc, user,trial);
            end
            
%             mov = VideoWriter(savePath) ;
%             mov.FrameRate = 25;
%             open(mov);
            
            data = expData{trial};
            
            
            %Define Targets
            target1 = [ data.target1Pose(1) - Lx_table/2       data.target1Pose(2) + Ly_table/2
                data.target1Pose(1) - Lx_table/2      data.target1Pose(2) - Ly_table/2
                data.target1Pose(1) + Lx_table/2     data.target1Pose(2) - Ly_table/2
                data.target1Pose(1) + Lx_table/2     data.target1Pose(2) + Ly_table/2
                data.target1Pose(1) - Lx_table/2      data.target1Pose(2) + Ly_table/2 ];
            
            target2 = [ data.target2Pose(1) - Lx_table/2       data.target2Pose(2) + Ly_table/2
                data.target2Pose(1) - Lx_table/2      data.target2Pose(2) - Ly_table/2
                data.target2Pose(1) + Lx_table/2     data.target2Pose(2) - Ly_table/2
                data.target2Pose(1) + Lx_table/2     data.target2Pose(2) + Ly_table/2
                data.target2Pose(1) - Lx_table/2      data.target2Pose(2) + Ly_table/2];
            
            
            % Draw initial figure
            fig = figure(counter+1);
            set(fig, 'Position', [50 50 560 420])

            set(fig,'units', 'normalized', 'outerposition',[0.3 0.1 0.6 0.8]);
            line (target1(:,1), target1(:,2), 'LineWidth',4,'Color',[.5 .5 .8]);
            line (target2(:,1), target2(:,2), 'LineWidth',4,'Color',[.5 .8 .5]);
            title(sprintf('Trial %d - %s SCENARIO', data.trial, data.conditionL{1}));
            
            xlabel('x','FontSize',14);
            ylabel('y','FontSize',14);
            zlabel('z','FontSize',14);
            
            set(gca,'FontSize',14);

            axis vis3d equal;
            view([-37.5,30]);
            camlight;
            
            grid on;
            xlim([-MAZE_WIDTH/2, MAZE_WIDTH/2]);
            ylim([-MAZE_DEPTH/2,MAZE_DEPTH/2]);
            zlim([0,3]);
            % set(gca,'XTick',[-4 4], 'YTick',[-4 4], 'ZTick',[-4 4]);
            
             
            
            if (sc == 3)
                line (obs1(:,1), obs1(:,2), 'LineWidth',4,'Color',[0 0 0]);
                line (obs2(:,1), obs2(:,2), 'LineWidth',4,'Color',[0 0 0]);
                line (obs3(:,1), obs3(:,2), 'LineWidth',4,'Color',[0 0 0]);
            end
            
            % Axes settings            
            xlabel('X axis [m]')
            ylabel('Y axis [m]')
            hold on
            set(fig,'units', 'normalized', 'outerposition',[0.3 0.1 0.6 0.8]);
            
            
            plot(data.linearKinematics(:,1), data.linearKinematics(:,2)); % plot the path
            
            % Time data
            t = (0 : 1 : length(data.angularKinematics)*1-1)';
            
            % Orientation data (x-y-z Euler angle)
            A = [0*t, 0*t, data.angularKinematics(:,1)];
            Aforces = [0*t, 0*t, data.angularKinematics(:,1)];
            
            % Motion data for the table, two participants and two forces
            r =  [    data.linearKinematics(:,1) - dia*cos(data.angularKinematics(:,1) + dia_angle) , ...
                data.linearKinematics(:,2) - dia*sin(data.angularKinematics(:,1) + dia_angle), ...
                0*t];
            r1 = [   data.linearKinematics(:,1) - ( (Lx_table+Lx1)/2 ) * cos(data.angularKinematics(:,1)) - dia1*cos(data.angularKinematics(:,1) + dia_angle1), ...
                data.linearKinematics(:,2) - ( (Lx_table+Lx1)/2 ) * sin(data.angularKinematics(:,1)) - dia1*sin(data.angularKinematics(:,1) + dia_angle1), ...
                0*t];
            r2 = [  data.linearKinematics(:,1) + ( (Lx_table+Lx2)/2 ) * cos(data.angularKinematics(:,1)) - dia2*cos(data.angularKinematics(:,1) + dia_angle2), ...
                data.linearKinematics(:,2) + ( (Lx_table+Lx2)/2 ) * sin(data.angularKinematics(:,1)) - dia2*sin(data.angularKinematics(:,1)+ dia_angle2), ...
                0*t];
            
            
            % height of the lines representing the agents' forces
            renderHeight = ones(length(r1),1)*Lz_table + 0.025;
            
            % end points of the lines representing the agents' forces
            f1Start = [r1(:,1:2), renderHeight];
            f2Start = [r2(:,1:2), renderHeight];
            fNet_agents = -(data.fOnCIP + data.fOnHIP);
            
            
%            vel = [data.linearKinematics(:,3) data.linearKinematics(:,4)];        % by measurement
            vel = [data.linearKinematics(:,5) data.linearKinematics(:,6)];        % by measurement
            velLength = sqrt((vel(:,1).^2) + (vel(:,2).^2)); % length of the velocity vector
            
            
            fCenterStart = [data.linearKinematics(:,1) data.linearKinematics(:,2) renderHeight];
            
            n_time = length(t);
            % Compute propagation of vertices and patches for the table, two participants
            % and two forces
            for i_time=1:40:n_time
                R = Euler2R(A(i_time,:));
                VertexData(:,:,i_time) = GeoVerMakeBlock(r(i_time,:),R,[Lx_table,Ly_table,Lz_table]);
                [X,Y,Z] = GeoPatMakeBlock(VertexData(:,:,i_time));
                PatchData_X(:,:,i_time) = X;
                PatchData_Y(:,:,i_time) = Y;
                PatchData_Z(:,:,i_time) = Z;
                
                
                VertexData1(:,:,i_time) = GeoVerMakeBlock(r1(i_time,:),R,[Lx1,Ly1,Lz1]);
                [X1,Y1,Z1] = GeoPatMakeBlock(VertexData1(:,:,i_time));
                PatchData_X1(:,:,i_time) = X1;
                PatchData_Y1(:,:,i_time) = Y1;
                PatchData_Z1(:,:,i_time) = Z1;
                
                VertexData2(:,:,i_time) = GeoVerMakeBlock(r2(i_time,:),R,[Lx2,Ly2,Lz2]);
                [X2,Y2,Z2] = GeoPatMakeBlock(VertexData2(:,:,i_time));
                PatchData_X2(:,:,i_time) = X2;
                PatchData_Y2(:,:,i_time) = Y2;
                PatchData_Z2(:,:,i_time) = Z2;
                
                f1End(i_time,:)     = f1Start(i_time,:) + [1 1 1] .* [data.fOnHIP(i_time, :) * SCALE_FACTOR       0];%* Rforces';
                f2End(i_time,:)     = f2Start(i_time,:) + [1 1 1] .* [data.fOnCIP(i_time, :) * SCALE_FACTOR     0];%* Rforces';
                
                fNetEnd_agents(i_time,:) = fCenterStart(i_time,:) - [fNet_agents(i_time,:) * SCALE_FACTOR  0] ;%* Rforces';
                
            end
            
            % Create table, grasp points, and force vectors
            h = patch(PatchData_X(:,:,1),PatchData_Y(:,:,1),PatchData_Z(:,:,1), 'w');
            set(h,'FaceLighting','phong','EdgeLighting','phong');
            set(h,'EraseMode','normal');
            
            
            h1 = patch(PatchData_X1(:,:,1),PatchData_Y1(:,:,1),PatchData_Z1(:,:,1),'b');
            set(h1,'FaceLighting','phong','EdgeLighting','phong');
            set(h1,'EraseMode','normal');
            
            
            h2 = patch(PatchData_X2(:,:,1),PatchData_Y2(:,:,1),PatchData_Z2(:,:,1),'g');
            set(h2,'FaceLighting','phong','EdgeLighting','phong');
            set(h2,'EraseMode','normal');
            
            % agents' forces
            hf1 = line( [f1Start(1,1) f1End(1,1)], ...
                [f1Start(1,2) f1End(1,2)], ...
                [f1Start(1,3) f1End(1,3)], ...
                'LineWidth',3,'Color','b');
            set(hf1,'EraseMode','normal');
            ha1 = arrowh([f1Start(1,1) f1End(1,1)],[f1Start(1,2) f1End(1,2)],renderHeight, 'b', 200);
            
            
            hf2 = line( [f2Start(1,1) f2End(1,1)], ...
                [f2Start(1,2) f2End(1,2)], ...
                [f2Start(1,3) f2End(1,3)], ...
                'LineWidth',3,'Color','g');
            ha2 = arrowh([f2Start(1,1) f2End(1,1)],[f2Start(1,2) f2End(1,2)],renderHeight, 'g', 200);
            
            
            % Animation Loop
            for i_time=1:40:n_time
                tableColor = 'm';
                
                set(h,'XData',PatchData_X(:,:,i_time));
                set(h,'YData',PatchData_Y(:,:,i_time));
                set(h,'ZData',PatchData_Z(:,:,i_time));
                set(h,'FaceColor', tableColor);
                
                set(h1,'XData',PatchData_X1(:,:,i_time));
                set(h1,'YData',PatchData_Y1(:,:,i_time));
                set(h1,'ZData',PatchData_Z1(:,:,i_time));
                
                set(h2,'XData',PatchData_X2(:,:,i_time));
                set(h2,'YData',PatchData_Y2(:,:,i_time));
                set(h2,'ZData',PatchData_Z2(:,:,i_time));
                
                set (hf1, 'XData', [f1Start(i_time,1) f1End(i_time,1)]);
                set (hf1, 'YData', [f1Start(i_time,2) f1End(i_time,2)]);
                set (hf1, 'ZData', [f1Start(i_time,3) f1End(i_time,3)]);
                
                set (hf2, 'XData', [f2Start(i_time,1) f2End(i_time,1)]);
                set (hf2, 'YData', [f2Start(i_time,2) f2End(i_time,2)]);
                set (hf2, 'ZData', [f2Start(i_time,3) f2End(i_time,3)]);
                
                delete(ha1); delete (ha2);
                
                ha1 = arrowh([f1Start(i_time,1) f1End(i_time,1)],[f1Start(i_time,2) f1End(i_time,2)],renderHeight, 'b', 200);
                ha2 = arrowh([f2Start(i_time,1) f2End(i_time,1)],[f2Start(i_time,2) f2End(i_time,2)],renderHeight, 'g', 200);
                
%                 writeVideo(mov, getframe(fig));
                drawnow;
            end
        
%         close(mov);
        close (fig);
        end
    end
   
end



