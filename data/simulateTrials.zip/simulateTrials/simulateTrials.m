%--------------------------------------------------------------------------
% Software License Agreement (BSD License)
%
%  Copyright (c) 2014, Koc University
%  All rights reserved.
%
%  Redistribution and use in source and binary forms, with or without
%  modification, are permitted provided that the following conditions
%  are met:
%
%   * Redistributions of source code must retain the above copyright
%     notice, this list of conditions and the following disclaimer.
%   * Redistributions in binary form must reproduce the above
%     copyright notice, this list of conditions and the following
%     disclaimer in the documentation and/or other materials provided
%     with the distribution.
%   * Neither the name of Koc University nor the names of its
%     contributors may be used to endorse or promote products derived
%     from this software without specific prior written permission.
%
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
%  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
%  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
%  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
%  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
%  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
%  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
%  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
%  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
%  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
%  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
%  POSSIBILITY OF SUCH DAMAGE.
%
% Author: Ayse Kucukyilmaz
%--------------------------------------------------------------------------

% Given data, create videos that simulate the interaction sequence
% It assumes that the data resides in a folder named matFiles under <PATH> 
%  directory (see below)
%
% The videos are put into a folder named videos under <PATH> 
%  directory (see below)
%--------------------------------------------------------------------------

clc;
clear;
close all;

% change this to point to the directory where you locate the mat files
PATH = '/home/ayse/Documents/research/ConflictRecognition/data/Koc_haptic_HHI_data/';


SCENES = [1 3];

DYADS = [1 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21];

TRIAL_COUNT = 10;

SCALE_FACTOR = 5; % for scaling the forces in visualization...

MAZE_WIDTH  = 200;
MAZE_HEIGHT = 5;
MAZE_DEPTH_ALL_SC = [30; 0; 83];

%Define obstacles for mixed scenario
obs1 = [  0 15; 100 15; 100 -15; 0 -15; 0 15];
obs2 = [ -100 41; -30 41; -30 15; -100 15; -100 41 ];
obs3 = [ -100 -41; -30 -41; -30 -15; -100 -15; -100 -41];

% Block specification; table and participants
Ly_table = 4;
Lx_table = 8;
Lz_table = 3;

dia = sqrt(((Lx_table/2)^2) + ((Ly_table/2)^2));
dia_angle = atan(Ly_table/Lx_table);

Ly1 = 0.1;
Lx1 = 0.1;
Lz1 = 0.1;
dia1 = sqrt(((Lx1/2)^2) + ((Ly1/2)^2));
dia_angle1 = atan(Ly1/Lx1);


Ly2 = 0.1;
Lx2 = 0.1;
Lz2 = 0.1;
dia2 = sqrt(((Lx2/2)^2) + ((Ly2/2)^2));
dia_angle2 = atan(Ly2/Lx2);

counter = 0;

for sc = SCENES
    
    MAZE_DEPTH = MAZE_DEPTH_ALL_SC(sc);
    for dyad = DYADS
        
        if dyad == 1 || dyad == 2 || dyad == 3 || dyad ==16
            perm = 0;
        elseif dyad == 4 || dyad==5 || dyad == 6 || dyad == 17
            perm = 1;
        elseif dyad ==7 || dyad == 8 || dyad == 9 || dyad ==18
            perm = 2;
        elseif dyad == 10 || dyad == 11 || dyad == 12 || dyad ==19 || dyad == 21
            perm = 3;
        else
            perm =4;
        end
        
        if(dyad < 10)
            filename = sprintf('%sexpData_d0%d_sc%d.mat', PATH, dyad, sc);
        else
            filename = sprintf('%sexpData_d%d_sc%d.mat', PATH, dyad, sc);
        end
        
        load (filename);
                
        for trial = 1:TRIAL_COUNT
            if dyad < 10
                savePath = sprintf('%s/videos/s0%d_d0%d_t%d.avi', PATH, sc, dyad, trial);
            else
                savePath = sprintf('%s/videos/s0%d_d%d_t%d.avi', PATH, sc, dyad, trial);
            end
            
             mov = VideoWriter(savePath) ;
             mov.FrameRate = 25;
             open(mov);
            
            data = expData{trial};
            
            
            %Define Targets
            target1 = [ data.target1Pose(1) - Lx_table/2       data.target1Pose(2) + Ly_table/2
                        data.target1Pose(1) - Lx_table/2      data.target1Pose(2) - Ly_table/2
                        data.target1Pose(1) + Lx_table/2     data.target1Pose(2) - Ly_table/2
                        data.target1Pose(1) + Lx_table/2     data.target1Pose(2) + Ly_table/2
                        data.target1Pose(1) - Lx_table/2      data.target1Pose(2) + Ly_table/2 ];
            
            target2 = [ data.target2Pose(1) - Lx_table/2       data.target2Pose(2) + Ly_table/2
                        data.target2Pose(1) - Lx_table/2      data.target2Pose(2) - Ly_table/2
                        data.target2Pose(1) + Lx_table/2     data.target2Pose(2) - Ly_table/2
                        data.target2Pose(1) + Lx_table/2     data.target2Pose(2) + Ly_table/2
                        data.target2Pose(1) - Lx_table/2      data.target2Pose(2) + Ly_table/2];
            
            
            % Draw initial figure
            fig = figure(counter+1);
            set(fig, 'Position', [50 50 560 420])
            
            set(fig,'units', 'normalized', 'outerposition',[0.3 0.1 0.6 0.8]);
            
            line (target1(:,1), target1(:,2), 'LineWidth',4,'Color',[.5 .5 .8]);
            line (target2(:,1), target2(:,2), 'LineWidth',4,'Color',[.5 .8 .5]);
            title(sprintf('DYAD: %d - SCENARIO: %s', dyad, strrep(data.scenarioName,'_','')));
            
            xlabel('x','FontSize',14);
            ylabel('y','FontSize',14);
            zlabel('z','FontSize',14);
            
            set(gca,'FontSize',14);

            axis vis3d equal;
            view([-37.5,30]);
            camlight;
            
            grid on;
            xlim([-MAZE_WIDTH/2, MAZE_WIDTH/2]);
            ylim([-MAZE_DEPTH/2,MAZE_DEPTH/2]);
            zlim([0,Lz_table * 2]);
            % set(gca,'XTick',[-4 4], 'YTick',[-4 4], 'ZTick',[-4 4]);
            
             
            
            if (sc == 3)
                line (obs1(:,1), obs1(:,2), 'LineWidth',4,'Color',[0.8 0.8 0.8]);
                line (obs2(:,1), obs2(:,2), 'LineWidth',4,'Color',[0.8 0.8 0.8]);
                line (obs3(:,1), obs3(:,2), 'LineWidth',4,'Color',[0.8 0.8 0.8]);
            end
            
            % Axes settings            
            xlabel('X axis [m]')
            ylabel('Y axis [m]')
            hold on
%             set(fig,'units', 'normalized', 'outerposition',[0.3 0.1 0.6 0.8]);
            
            
            plot(data.pose(:,1), data.pose(:,2)); % plot the path
            
            % Time data
            t = (0 : 1 : length(data.pose)*1-1)';
            
            % Orientation data (x-y-z Euler angle)
            A = [0*t, 0*t, data.pose(:,3)];
            
            % Motion data for the table, two participants and two forces
            r =  [  data.pose(:,1) - dia*cos(data.pose(:,3) + dia_angle) , ...
                    data.pose(:,2) - dia*sin(data.pose(:,3) + dia_angle), ...
                    0*t];
            r1 = [  data.pose(:,1) - ( (Lx_table+Lx1)/2 ) * cos(data.pose(:,3)) - dia1*cos(data.pose(:,3) + dia_angle1), ...
                    data.pose(:,2) - ( (Lx_table+Lx1)/2 ) * sin(data.pose(:,3)) - dia1*sin(data.pose(:,3) + dia_angle1), ...
                    0*t];
            r2 = [  data.pose(:,1) + ( (Lx_table+Lx2)/2 ) * cos(data.pose(:,3)) - dia2*cos(data.pose(:,3) + dia_angle2), ...
                    data.pose(:,2) + ( (Lx_table+Lx2)/2 ) * sin(data.pose(:,3)) - dia2*sin(data.pose(:,3)+ dia_angle2), ...
                    0*t];
            
            
            % height of the lines representing the agents' forces
            renderHeight = ones(length(r1),1) * Lz_table + 0.025;
            
            % end points of the lines that represent the agents' forces
            f1Start = [r1(:,1:2), renderHeight];
            f2Start = [r2(:,1:2), renderHeight];
                        
            n_time = length(t);
            % Compute propagation of vertices and patches for the table, two participants
            % and two forces at 25 Hertz
            idx = 1; % introduce a new index as we only need 25 Hertz data
            for i_time=1:40:n_time
                R = Euler2R(A(i_time,:));
                VertexData(:,:,idx) = GeoVerMakeBlock(r(i_time,:),R,[Lx_table,Ly_table,Lz_table]);
                [X,Y,Z] = GeoPatMakeBlock(VertexData(:,:,idx));
                PatchData_X(:,:,idx) = X;
                PatchData_Y(:,:,idx) = Y;
                PatchData_Z(:,:,idx) = Z;
                
                VertexData1(:,:,idx) = GeoVerMakeBlock(r1(i_time,:),R,[Lx1,Ly1,Lz1]);
                [X1,Y1,Z1] = GeoPatMakeBlock(VertexData1(:,:,idx));
                PatchData_X1(:,:,idx) = X1;
                PatchData_Y1(:,:,idx) = Y1;
                PatchData_Z1(:,:,idx) = Z1;
                
                VertexData2(:,:,idx) = GeoVerMakeBlock(r2(i_time,:),R,[Lx2,Ly2,Lz2]);
                [X2,Y2,Z2] = GeoPatMakeBlock(VertexData2(:,:,idx));
                PatchData_X2(:,:,idx) = X2;
                PatchData_Y2(:,:,idx) = Y2;
                PatchData_Z2(:,:,idx) = Z2;
                
                % the matrices need to be of same size with f1Start, hence
                % use i_time instead of idx for the index
                f1End(i_time,:)     = f1Start(i_time,:) - [data.fOnHIP1(i_time, :) * SCALE_FACTOR     0];%* A';
                f2End(i_time,:)     = f2Start(i_time,:) - [data.fOnHIP2(i_time, :) * SCALE_FACTOR     0];%* A';
                                
                idx = idx + 1;
            end
            
            % Create table, grasp points, and force vectors
            h = patch(PatchData_X(:,:,1),PatchData_Y(:,:,1),PatchData_Z(:,:,1), 'w');
            set(h,'FaceLighting','phong','EdgeLighting','phong');
            set(h,'EraseMode','normal');
            
            
            h1 = patch(PatchData_X1(:,:,1),PatchData_Y1(:,:,1),PatchData_Z1(:,:,1),'b');
            set(h1,'FaceLighting','phong','EdgeLighting','phong');
            set(h1,'EraseMode','normal');
            
            
            h2 = patch(PatchData_X2(:,:,1),PatchData_Y2(:,:,1),PatchData_Z2(:,:,1),'g');
            set(h2,'FaceLighting','phong','EdgeLighting','phong');
            set(h2,'EraseMode','normal');
            
            % agents' forces
            hf1 = line( [f1Start(1,1) f1End(1,1)], ...
                        [f1Start(1,2) f1End(1,2)], ...
                        [f1Start(1,3) f1End(1,3)], ...
                        'LineWidth',2,'Color','b');
            set(hf1,'EraseMode','normal');  
            ha1 = arrowh([f1Start(1,1) f1End(1,1)], [f1Start(1,2) f1End(1,2)], f1End(1,3), 'b', 250);
            
            
            hf2 = line( [f2Start(1,1) f2End(1,1)], ...
                        [f2Start(1,2) f2End(1,2)], ...
                        [f2Start(1,3) f2End(1,3)], ...
                        'LineWidth',2,'Color','g');
            ha2 = arrowh([f2Start(1,1) f2End(1,1)], [f2Start(1,2) f2End(1,2)], f2End(1,3), 'g', 250);
            
            
            % Animation Loop @ 25 Hertz
            tableColor = 'm';
            for i_time=1:40:n_time
                
                idx = (i_time - 1) / 40 + 1;
                
                set(h, 'XData', PatchData_X(:,:,idx));
                set(h, 'YData', PatchData_Y(:,:,idx));
                set(h, 'ZData', PatchData_Z(:,:,idx));
                set(h, 'FaceColor', tableColor);
                
                set(h1, 'XData', PatchData_X1(:,:,idx));
                set(h1, 'YData', PatchData_Y1(:,:,idx));
                set(h1, 'ZData', PatchData_Z1(:,:,idx));
                
                set(h2, 'XData', PatchData_X2(:,:,idx));
                set(h2, 'YData', PatchData_Y2(:,:,idx));
                set(h2, 'ZData', PatchData_Z2(:,:,idx));
                                
                set (hf1, 'XData', [f1Start(i_time,1) f1End(i_time,1)]);
                set (hf1, 'YData', [f1Start(i_time,2) f1End(i_time,2)]);
                set (hf1, 'ZData', [f1Start(i_time,3) f1End(i_time,3)]);
                                  
                set (hf2, 'XData', [f2Start(i_time,1) f2End(i_time,1)]);
                set (hf2, 'YData', [f2Start(i_time,2) f2End(i_time,2)]);
                set (hf2, 'ZData', [f2Start(i_time,3) f2End(i_time,3)]);
                
                delete(ha1); delete (ha2);
                
                ha1 = arrowh([f1Start(i_time,1) f1End(i_time,1)], [f1Start(i_time,2) f1End(i_time,2)], f1End(i_time,3), 'b', 200);
                ha2 = arrowh([f2Start(i_time,1) f2End(i_time,1)], [f2Start(i_time,2) f2End(i_time,2)], f1End(i_time,3), 'g', 200);
                
                 writeVideo(mov, getframe(fig));
                drawnow;
            end
        
         close(mov);
        close (fig);
        end
    end
   
end



